# Random Spectrum

Windows 10/11 向けのネイティブ・オーディオスペクトラムアナライザーです。WASAPI ループバックで Windows の既定の再生デバイスから出力音声を取り込み、64 の周波数帯域を描画します。音楽や動画を再生した状態で `RandomSpectrum.exe` を起動してください。Windows で既定の出力先を変更すると、アプリも追従します。

## 操作

| 操作 | 方法 |
| --- | --- |
| 設定を開く | **Settings**、右クリック、または **F1** |
| ウインドウ／全画面を切り替える | **Fullscreen** または **F11**。全画面からは **Esc** でも戻れます |
| パターンを選ぶ | 設定の **Pattern** からカテゴリを開く |
| 次のパターンへ | **Next pattern** または **→** |
| 前のパターンに戻る | **Previous pattern** または **←** |
| 配色だけ変更する | 設定の **Palette**、**Next palette**、または **P** |
| 前の配色に戻る | **Previous palette** または **Shift+P** |
| 描画の目標FPSを変更する | 設定の **Frame rate** |
| 終了する | **Exit** または **Alt+F4** |

**Randomize on silence** は、再生後に約 1 秒間の無音が続いたときに、無音区間につき一度だけ切り替わります。

- **Off** はパターンと配色の自動切り替えを停止します。
- **Pattern and palette** はパターンと配色を切り替えます。
- **Palette only** は現在のパターンのまま配色だけを切り替えます。
- **Lock palette** は無音時と一定時間ごとの配色の自動切り替えを止めます。**Pattern and palette** と併用するとパターンだけが切り替わります。配色の手動変更もできます。

**Palette interval** で、再生中も含めて配色を切り替える間隔を選べます。初期値は30秒で、5秒、10秒、15秒、30秒、1分、2分、5分から選べます。この項目を **Off** にすると時間による切り替えだけが止まり、無音による切り替えは **Randomize on silence** の設定に従います。切り替え後は次の間隔を最初から数え、配色は約1.2秒かけて移り変わります。

無音になるとスペクトラムが約0.7秒で黒い背景に溶け込みます。音が戻ると、その時点のパターンと配色が約0.4秒かけて浮かび上がります。

**Frame rate** では目標値を 10、15、20、30、60 FPS から選べます。初期値は30 FPSです。低い設定にすると描画と周波数分析の頻度が下がり、完全に黒くなった表示は状態が変わる時だけ再描画します。

設定メニューで選んだ項目は Windows のユーザーごとに保存されます。描画は全40パターンです。**Pattern** は **Simple & classic**、**Nature & water**、**Space**、**Lights & celebrations**、**Geometry & motion** の5カテゴリに分かれています。棒、点、細線、円弧などのシンプルな新作10種類は **Simple & classic** に入っています。

前へ戻る操作では、自動切り替えを含むセッション中の履歴をたどれます。履歴の先頭からさらに戻ると一覧順に戻り、次のパターンは履歴を進むか、履歴の末尾ならカテゴリ順に進みます。
配色は既存の5種類と、レインボー・偏光系3種類、メタリック系4種類、蛍光系4種類、パステル系4種類の計20種類です。

## Windows でビルド

CMake 3.21 以降と、Visual Studio 2022 Build Tools の「C++ によるデスクトップ開発」ワークロードを使用します。

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
```

実行ファイルは `build/Release/RandomSpectrum.exe` です。Linux で FFT と無音判定のテストを行う場合は、C++17 コンパイラと CMake を使用します。

```sh
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```
