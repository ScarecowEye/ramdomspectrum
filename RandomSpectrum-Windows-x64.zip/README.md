# Random Spectrum

Windows 10/11 向けのネイティブ・オーディオスペクトラムアナライザーです。WASAPI ループバックで Windows の既定の再生デバイスから出力音声を取り込み、64 の周波数帯域を描画します。音楽や動画を再生した状態で `RandomSpectrum.exe` を起動してください。Windows で既定の出力先を変更すると、アプリも追従します。

## 操作

| 操作 | 方法 |
| --- | --- |
| 設定を開く | **Settings**、右クリック、または **F1** |
| ウインドウ／全画面を切り替える | **Fullscreen** または **F11**。全画面からは **Esc** でも戻れます |
| パターンだけ変更する | 設定の **Pattern** |
| 配色だけ変更する | 設定の **Palette**、**Next palette**、または **P** |
| 終了する | **Exit** または **Alt+F4** |

**Randomize on silence** は、再生後に約 1 秒間の無音が続いたときに、無音区間につき一度だけ切り替わります。

- **Off** は自動切り替えを停止します。
- **Pattern and palette** はパターンと配色を切り替えます。
- **Palette only** は現在のパターンのまま配色だけを切り替えます。
- **Lock palette** は配色の自動切り替えを止めます。**Pattern and palette** と併用するとパターンだけが切り替わります。配色の手動変更もできます。

設定メニューで選んだ項目は Windows のユーザーごとに保存されます。パターンは Orbit、Prism、Tide、Grid の4種類で、配色は Aurora、Ember、Nocturne、Glacier、Solar の5種類です。

## Windows でビルド

CMake 3.21 以降と、Visual Studio 2022 Build Tools の「C++ によるデスクトップ開発」ワークロードを使用します。

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
```

実行ファイルは `build/Release/RandomSpectrum.exe` です。Linux で FFT と無音判定のテストを行う場合は、C++17 コンパイラと CMake を使用します。

```sh
cmake -S . -B build
cmake --build build
ctest --test-dir build --output-on-failure
```
